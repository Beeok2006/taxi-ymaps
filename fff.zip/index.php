
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Рассчёт стоимости</title>
    
    <script src="https://api-maps.yandex.ru/2.1/?lang=ru_RU&apikey=0161b7e7-244e-486b-808a-41ea17c36a4c&suggest_apikey=9f00bbc4-6416-4ba1-b223-930382c56d17" type="text/javascript"></script>
    <link href="https://unpkg.com/bootstrap@3.3.2/dist/css/bootstrap.min.css" rel="stylesheet"/>
<script src="https://unpkg.com/jquery@3.3.1/dist/jquery.min.js"></script>
<script src="https://unpkg.com/bootstrap@3.3.2/dist/js/bootstrap.min.js"></script>
<script src="https://unpkg.com/bootstrap-multiselect@0.9.13/dist/js/bootstrap-multiselect.js"></script>
<link href="https://unpkg.com/bootstrap-multiselect@0.9.13/dist/css/bootstrap-multiselect.css" rel="stylesheet"/>
<link href="style.css" rel="stylesheet">

<style>
    .inputers{
        color: rgb(0, 0, 0);
    background-color: rgb(255, 255, 255);
    border-radius: 30px;
    font-size: 14px;
    font-weight: 500;
    margin-top:20px;
    height: 35px;
    }
    .inputerg{
        border-radius: 30px;
    background-color: #47a76a;
    background-position: center center;
    border-color: transparent;
    border-style: solid;
    color:white;
    }
    @media screen and (max-width: 479px) {
    .h1n {
       line-height: 25px;
       font-size:16px;
    }
    
}
  @media screen and (max-width: 479px) {
    .t-input {
      width:320px;
    }

.t-input {
    margin: 0;
    font-size: 100%;
    height: 60px;
    padding: 0 20px;
    font-size: 16px;
    line-height: 1.33;
    width: 93%;
    border: 0 none;
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    box-sizing: border-box;
    outline: 0;
    -webkit-appearance: none;
    border-radius: 0
}

.t-input::-moz-focus-inner {
    padding: 0;
    border: 0
}

.t-input_bbonly {
    outline: 0;
    padding-left: 0!important;
    padding-right: 0!important;
    border-top: 0!important;
    border-right: 0!important;
    border-left: 0!important;
    background-color: transparent!important;
    border-radius: 0!important;
    border-bottom: 1px solid
}

.t-input_pvis {
    padding: 26px 20px 10px 20px
}

.tn-atom__form .t-input_pvis {
    padding: 26px 20px 10px 20px!important
}

.t-input__vis-ph {
    font-size: 16px;
    line-height: 1;
    opacity: .5;
    position: absolute;
    left: 20px;
    top: 22px;
    height: 17px;
    -webkit-transform: translateZ(0);
    transform: translateZ(0);
    -webkit-transition: transform .2s linear;
    transition: transform .2s linear;
    -webkit-transform-origin: left;
    transform-origin: left;
    pointer-events: none;
    white-space: nowrap;
    width: 100%;
    width: calc(100% - 40px);
    text-overflow: ellipsis;
    overflow: hidden
}

.t-input:focus~.t-input__vis-ph,.t-input_has-content+.t-input__vis-ph {
    -webkit-transform: translateY(-100%) scale(.7);
    transform: translateY(-100%) scale(.7);
    text-overflow: inherit;
    width: auto
}

.t-input:invalid {
    box-shadow: none
}


.input-res
{
  -webkit-appearance: none;
  -moz-appearance: none;
  appearance: none;
  font: 15px/1 'Open Sans', sans-serif;
  color: #333;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  width: 45%;
  max-width: 500px;
  background-color: #fff;
  border: none;
  padding: 10px 11px 11px 11px;
  border-radius: 3px;
  height:35px;
  box-shadow: none;
  outline: none;
  margin: 0;
  border-radius:12px;
  box-sizing: border-box; 
}
.multiselect-selected-text{
    color:white;
    margin-bottom:20px;   
}
  @media screen and (max-width: 479px) {
    .opt, .opts {
      width:388px;
    }
  }
     @media screen and (max-width: 479px) {
    .btn-group, .multiselect dropdown-toggle btn btn-default{
       width: 188px;
      
    }
     }
     body{
         color: black;
     }
.btn-default{
        background-color: #37993a;
}

/* CSS */
.button-37 {
  background-color: #13aa52;
  border: 1px solid #13aa52;
  border-radius: 4px;
  box-shadow: rgba(0, 0, 0, .1) 0 2px 4px 0;
  box-sizing: border-box;
  color: #fff;
  cursor: pointer;
  font-family: "Akzidenz Grotesk BQ Medium", -apple-system, BlinkMacSystemFont, sans-serif;
  font-size: 16px;
  font-weight: 400;
  outline: none;
  outline: 0;
  padding: 10px 25px;
  text-align: center;
  transform: translateY(0);
  transition: transform 150ms, box-shadow 150ms;
  user-select: none;
  -webkit-user-select: none;
  touch-action: manipulation;
}

.button-37:hover {
  box-shadow: rgba(0, 0, 0, .15) 0 3px 9px 0;
  transform: translateY(-2px);
}

@media (min-width: 768px) {
  .button-37 {
    padding: 10px 30px;
  }
}
</style>
</head>
<body>
    <img src="images/taxes.png" style="width: 22%;
    margin-bottom: -52px;">
<h1 class="h1n" style="color:#b5f698;    padding: 20px;">Междугороднее такси/трансфер</h1>   
<form action="telegram.php" method="POST" style="display: flex;
    flex-direction: row-reverse;
    flex-wrap: wrap;
    align-content: stretch;
    align-items: center;
    justify-content: space-evenly;">
    
    <input type="text" style="color: rgb(0, 0, 0);
    background-color: rgb(255, 255, 255);
    border-radius: 12px;
    font-size: 17px;
    font-weight: 500;
    height: 35px;margin-bottom:20px;" class="t-input js-tilda-rule t-input-inline-styles"  id="startAddress" name="user_suggestion" placeholder="Откуда">
    <input type="text" style="color: rgb(0, 0, 0);
    background-color: rgb(255, 255, 255);
    border-radius: 12px;
    font-size: 17px;
    font-weight: 500;
    height: 35px;margin-bottom: 20px;
    " class="t-input js-tilda-rule t-input-inline-styles" id="endAddress" name="end_address" placeholder="Куда">
    <input type="text" class="input-res" style="margin-bottom:20px;" id="name" name="user_name" placeholder="Ваше Имя">
    <input type="text" class="input-res" style="margin-bottom:20px;" id="phone" name="user_phone" placeholder="Ваш номер">
   
 
  <div class="opt">
   <label  class="t-input-title"  style="display: block; color: rgb(255, 219, 88); font-family: Arial; padding-bottom: 5px; font-size: 14px; font-weight: 400;">Доп Опции</label>
<select id="chkveg" name="chkveg" class="input-res" multiple="multiple" style="margin-bottom: 20px;background: green;
    height: 35px;
    border-radius: 12px;" >
   
      <option value="323">Большой багажник</option>
      <option value="439">
          Детское кресло</option>
      <option value="79">Люлька</option>
      <option value="59">Перевозка животного</option>
      <option value="40">Трезвый водитель</option>
      <option value="10">Встреча с табличко</option>
       <option value="200">Курящий салон</option>
      <option value="300">Водитель женщина</option>
      <option value="400">Пересечение АПП</option>
      <option value="500">Пересечение МАПП</option>
    </select>
  <br><br><br>
   <select size="1" name="tarife" class="input-res"  id="tarife" style="margin-bottom: 20px;width: 168px;
    height: 35px;
    border-radius: 12px;">
    <option disabled>Выберите тариф</option>
    <option selected value="10">Стандарт</option>
    <option  value="20">Комфорт</option>
     <option value="30">Минивен 6 мест</option>
    <option  value="40">Минивен 8 мест</option>
      <option value="50">Буксировка</option>
    <option  value="60">Перегон авто</option>
      <option value="70">Эконом</option>
   </select>
   </div>
   <div class="opts" style="margin-bottom:20px;">
    <input id="startDate" name="start_date" style="margin-right: 60px;border-radius: 14px;
    padding: 8px;
    border: none;
    width: 128px;" type="text" placeholder="Дата" min="0" step="0.001" onkeypress="this.value=this.value.substring(0,4)">
    <input type="text" id="appt" style="    width: 75px;border-radius: 14px;
    padding: 8px;
    border: none;"   id="startTime" name="start_time" style="width: 98px;" inputmode="numeric" placeholder="Время (например: 14:00)" min="0" step="0.001" onkeypress="this.value=this.value.substring(0,4)">
    
    </div>
    <div class="opts">
        
       
        <input type="text" readonly id="calculatedPrice" style="width:170px;border-radius: 12px;
    height: 35px;" name="calculated_price">
         <button type="button" class="inputerg" id="calculate">Рассчитать стоимость</button>
    </div>
   <br><br><br><br>
    <input type="submit" class="inputerg button-37" style="margin-right: 244px;" value="Отправить">
    
</form>


<script>
    ymaps.ready(function() {
        var options = {
            boundedBy: [[32, 19], [82, 69]],
            results: 5
        };

        new ymaps.SuggestView('startAddress', options);
        new ymaps.SuggestView('endAddress', options);

        document.getElementById("calculate").addEventListener("click", function() {
            const start = document.getElementById("startAddress").value;
            const end = document.getElementById("endAddress").value;
            const tarife = document.getElementById("tarife").value;
            const options =  $('#chkveg').val().map(Number);
            const sum = options.reduce((partialSum, a) => partialSum + a, 0);
  

        

            getDistance(start, end).then(distance => {
                const pricePerKm = 10; 
                const totalPrice = Math.round(distance * parseInt(tarife) + sum);
                

                document.getElementById("calculatedPrice").value = totalPrice;
                document.getElementById("priceDisplay").textContent = totalPrice;
            });
        });
    });

    function getDistance(start, end) {
        return new Promise((resolve, reject) => {
            var myGeocoder = ymaps.geocode(start);
            myGeocoder.then(startRes => {
                var startCoords = startRes.geoObjects.get(0).geometry.getCoordinates();
                
                var myGeocoder2 = ymaps.geocode(end);
                myGeocoder2.then(endRes => {
                    var endCoords = endRes.geoObjects.get(0).geometry.getCoordinates();

                    var distance = ymaps.coordSystem.geo.getDistance(startCoords, endCoords) / 1000;
                    resolve(distance);
                });
            });
        });
    }
    
    
$(function() {
    
    $('#chkveg').multiselect({
        
        includeSelectAllOption: true
    });
    
 
});


</script>
<script>
    $(document).ready(function()
{
  $('#load-more-content').click(function()
  {
    
    $('#more-content').toggleClass('shown');

    $('#load-more-content').hide();

    if( $('#more-content').hasClass('shown') )
    {
      $('#load-more-content').text('Hide content');
      $('#more-content').fadeIn('slow', function()
      {
        $('#load-more-content').fadeIn('slow');
      });
    }
    else
    {
      $('#load-more-content').text('Load some content');
      $('#more-content').fadeOut('slow', function()
      {
        $('#load-more-content').fadeIn('slow');
      });
    }
  });
});
</script>
</body>
</html>