<?php

$name = $_POST['user_name'];
$phone = $_POST['user_phone'];
// $email = $_POST['user_email'];
$startAddress = $_POST['user_suggestion'];
$endAddress = $_POST['end_address'];
$date = $_POST['start_date'];
$time = $_POST['start_time'];
$price = $_POST['calculated_price'];
$tarife = $_POST['tarife'];
$options = $_POST['chkveg'];


$token = "6032025212:AAFGle8TVnOBvBQQyzGhJNC8FQLa-xj5yrU";
$chat_id = "-4009499712";

$arr = array(
    'Имя пользователя: ' => $name,
    'Телефон: ' => $phone,
    // 'Email' => $email,
    'Откуда:' => $startAddress,
    'Куда:' => $endAddress,
    'Дата:' => $date,
    'Время:' => $time,
    'Стоимость поездки: ' => $price . ' руб.',
    'Тариф' => $tarife,
    'Опции' => $options,
    
);

$txt = "";
foreach($arr as $key => $value) {
    $txt .= "<b>".$key."</b> ".$value."%0A";
};

$url = "https://api.telegram.org/bot{$token}/sendMessage?chat_id={$chat_id}&parse_mode=html&text={$txt}";

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
$response = curl_exec($ch);
curl_close($ch);

$responseArray = json_decode($response, true);

if ($responseArray['ok'] == true) {
    header('Location: thank-you.html');
} else {
    echo "Error: " . $responseArray['description'];
}

?>
